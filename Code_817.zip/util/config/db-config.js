
const config = {
  "development": {

      "host":"localhost",
      "database": "church",
      "user" : "root",
      "password": "tanzeel10"
  },

  "production":{
    "host":"68.66.224.6",
     "user":"cdamechu_cdamechu",
     "password":"YN32(9-b4eWiVw",
     "database":"cdamechu_churchdb"
  }



}
module.exports = config;

/*
"production":{
    "host":"sql12.freemysqlhosting.net",
     "user":"sql12301366",
     "password":"HVnZJSM9vk",
     "database":"sql12301366"
} */
